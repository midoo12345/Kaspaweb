# Implementation Guide

Technical implementation details for Kaspa Websites.

## Architecture

### Components

1. **Web Interface** (`web/kaspa-websites-complete.html`)
   - Single HTML file with embedded CSS and JavaScript
   - Tab-based UI (Create / View)
   - KasWare wallet integration
   - Encryption/decryption logic

2. **Chrome Extension** (`extension/`)
   - Manifest V3 extension
   - Popup interface for viewing
   - Background script handling
   - Link navigation system

## Data Flow

### Creating a Website

```
User Input (HTML)
    ↓
[Optional] Encrypt with password
    ↓
Convert to hex
    ↓
[Optional] Add ENC1 marker
    ↓
Send via KasWare to Kaspa blockchain
    ↓
Receive Transaction ID
```

### Viewing a Website

```
Transaction ID
    ↓
Fetch from Kaspa API
    ↓
Extract payload from transaction
    ↓
Decode hex to text
    ↓
[If encrypted] Detect ENC1 marker
    ↓
[If encrypted] Prompt for password
    ↓
[If encrypted] Decrypt AES-256-GCM
    ↓
Render HTML in new tab
    ↓
[Optional] Intercept TX ID links
```

## Encryption Implementation

### Encryption Process

```javascript
async function encryptHTML(html, password) {
    // 1. Convert password to key
    const passwordKey = await crypto.subtle.importKey('raw', 
        new TextEncoder().encode(password), 'PBKDF2', false, 
        ['deriveBits', 'deriveKey']);
    
    // 2. Generate random salt (16 bytes)
    const salt = crypto.getRandomValues(new Uint8Array(16));
    
    // 3. Derive AES key from password
    const key = await crypto.subtle.deriveKey({
        name: 'PBKDF2',
        salt: salt,
        iterations: 100000,
        hash: 'SHA-256'
    }, passwordKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
    
    // 4. Generate random IV (12 bytes)
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    // 5. Encrypt the HTML
    const encrypted = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        new TextEncoder().encode(html)
    );
    
    // 6. Combine salt + IV + encrypted data
    const result = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
    result.set(salt, 0);
    result.set(iv, salt.length);
    result.set(new Uint8Array(encrypted), salt.length + iv.length);
    
    // 7. Convert to hex
    return Array.from(result).map(b => b.toString(16).padStart(2, '0')).join('');
}
```

### Decryption Process

```javascript
async function decryptHTML(encryptedHex, password) {
    // 1. Convert hex to bytes
    const bytes = new Uint8Array(
        encryptedHex.match(/.{1,2}/g).map(byte => parseInt(byte, 16))
    );
    
    // 2. Extract salt, IV, and encrypted data
    const salt = bytes.slice(0, 16);
    const iv = bytes.slice(16, 28);
    const encryptedData = bytes.slice(28);
    
    // 3. Derive key from password (same as encryption)
    const passwordKey = await crypto.subtle.importKey('raw',
        new TextEncoder().encode(password), 'PBKDF2', false,
        ['deriveBits', 'deriveKey']);
    
    const key = await crypto.subtle.deriveKey({
        name: 'PBKDF2',
        salt: salt,
        iterations: 100000,
        hash: 'SHA-256'
    }, passwordKey, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
    
    // 4. Decrypt
    const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        encryptedData
    );
    
    // 5. Convert to string
    return new TextDecoder().decode(decrypted);
}
```

## Link Navigation Implementation

### Detection Pattern

```javascript
const KASPA_TX_ID_PATTERN = /^[0-9a-fA-F]{64}$/;
```

### Interception Script

```javascript
function interceptKaspaLinks(html) {
    const script = `
        <script>
        (function() {
            document.addEventListener('click', function(e) {
                const link = e.target.closest('a');
                if (!link) return;
                
                const href = link.getAttribute('href');
                if (!href || !/^[0-9a-fA-F]{64}$/.test(href)) return;
                
                e.preventDefault();
                window.open('kaspawebsites.html?tx=' + href + '#decoder', '_blank');
            }, false);
        })();
        </script>
    `;
    
    return html.replace(/<\/body>/i, script + '</body>') || html + script;
}
```

### URL Parameter Handling

```javascript
window.addEventListener('load', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const txId = urlParams.get('tx');
    if (txId) {
        switchTab('decoder');
        document.getElementById('txId').value = txId;
        setTimeout(() => decodeTransaction(), 500);
    }
});
```

## Kaspa API Integration

### Fetching Transaction Data

```javascript
const response = await fetch(`https://api.kaspa.org/transactions/${txId}`);
const txData = await response.json();
```

### Extracting Payload

```javascript
let payload = null;

// Try txData.payload first
if (txData.payload) {
    payload = txData.payload;
}

// Fallback: check outputs
else if (txData.outputs && txData.outputs.length > 0) {
    for (const output of txData.outputs) {
        if (output.scriptPublicKey) {
            payload = output.scriptPublicKey;
            break;
        }
    }
}
```

## Hex Encoding/Decoding

### String to Hex

```javascript
function stringToHex(str) {
    return Array.from(str)
        .map(char => char.charCodeAt(0).toString(16).padStart(2, '0'))
        .join('');
}
```

### Hex to String (with double-decode detection)

```javascript
function hexToString(hex) {
    hex = hex.replace(/^0x/, '');
    
    let str = '';
    for (let i = 0; i < hex.length; i += 2) {
        const charCode = parseInt(hex.substr(i, 2), 16);
        str += String.fromCharCode(charCode);
    }
    
    // Detect double-encoding
    if (str.startsWith('0x') || str.startsWith('30783')) {
        console.log('Detected double-encoded payload, decoding again...');
        return hexToString(str);
    }
    
    return str;
}
```

## KasWare Integration

### Wallet Detection

```javascript
if (typeof window.kasware === 'undefined') {
    alert('KasWare wallet not detected. Please install KasWare extension.');
    return;
}

if (window.location.protocol !== 'https:' && window.location.hostname !== 'localhost') {
    alert('KasWare requires HTTPS. Please use HTTPS or localhost.');
    return;
}
```

### Sending Transaction

```javascript
const txId = await window.kasware.sendKaspa(
    recipient,
    amountSompi,
    { payload: hexPayload }
);

// Extract ID from response
const transactionId = typeof txId === 'string' ? txId : 
    (txId.id || JSON.parse(txId).id);
```

## Image Embedding

### File to Base64

```javascript
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}
```

### Embedding Process

```javascript
async function embedImages() {
    const files = document.getElementById('imageUpload').files;
    let htmlSnippets = '\n<!-- Embedded Images -->\n';
    
    for (let file of files) {
        // Warn if large
        if (file.size > 100000) {
            if (!confirm(`${file.name} is large. Continue?`)) continue;
        }
        
        // Convert to base64
        const base64 = await fileToBase64(file);
        
        // Generate HTML tag
        htmlSnippets += `<img src="${base64}" alt="${file.name}" ` +
                       `style="max-width: 100%;">\n`;
    }
    
    // Append to HTML editor
    document.getElementById('htmlInput').value += htmlSnippets;
}
```

## Security Considerations

### Content Security Policy

```html
<meta http-equiv="Content-Security-Policy" 
      content="default-src * 'unsafe-inline' 'unsafe-eval' data: blob:;">
```

### HTTPS Enforcement

- KasWare requires HTTPS
- Mixed content (HTTP images) blocked by browsers
- Recommend HTTPS-only external resources

### Password Security

- Never stored or transmitted
- Used only for client-side encryption/decryption
- PBKDF2 with 100,000 iterations
- Lost passwords cannot be recovered

## Error Handling

### Transaction Errors

```javascript
try {
    const txId = await window.kasware.sendKaspa(...);
} catch (error) {
    if (error.message.includes('User rejected')) {
        showStatus('Transaction cancelled', 'error');
    } else if (error.message.includes('Insufficient')) {
        showStatus('Insufficient balance', 'error');
    } else {
        showStatus('Transaction failed: ' + error.message, 'error');
    }
}
```

### Decryption Errors

```javascript
try {
    const decrypted = await decryptHTML(hex, password);
} catch (error) {
    showStatus('Wrong password or corrupted data', 'error');
    return;
}
```

## Performance Optimization

### Payload Size Limits

- Keep total HTML under 100KB
- Compress images before embedding
- Use external hosting for large media
- Consider splitting content across multiple transactions

### Caching

- Browser caches blob URLs
- Extension can cache recent transactions
- Consider implementing localStorage cache

## Testing

### Test Cases

1. **Basic HTML** - Simple page without encryption
2. **Encrypted HTML** - Password-protected content
3. **Linked Pages** - Multiple pages with TX ID links
4. **Embedded Images** - Base64 images
5. **External Images** - HTTPS image URLs
6. **Large Payloads** - Test size limits
7. **Double-Encoding** - Old transaction compatibility
8. **Invalid TX IDs** - Error handling
9. **Wrong Passwords** - Decryption failure
10. **Network Errors** - API unavailable

### Browser Testing

- Chrome/Edge
- Firefox
- Safari (limited KasWare support)
- Mobile browsers

## Deployment

### Web Interface

1. Upload `kaspa-websites-complete.html` to web server
2. Ensure HTTPS is enabled
3. Test KasWare connection

### Extension

1. Build extension package
2. Add icons (16x16, 48x48, 128x128)
3. Submit to Chrome Web Store
4. Provide installation instructions

## Maintenance

### Updates

- Monitor Kaspa API changes
- Update KasWare integration as needed
- Fix browser compatibility issues
- Add new features

### Support

- GitHub issues for bug reports
- Documentation updates
- Community feedback

## Future Enhancements

- Server-side transaction indexing
- Search functionality
- Website templates
- CMS integration
- Analytics
- Comments/interaction

# Kaspa Websites Viewer - Chrome Extension v2.0

View HTML websites stored on the Kaspa blockchain with encryption support and link navigation.

## New Features in v2.0

✅ **Encryption Support**
- Decrypt password-protected websites
- Password prompt with show/hide toggle
- AES-256-GCM encryption support

✅ **Link Navigation**
- Click Kaspa TX ID links to navigate between blockchain pages
- Automatic detection of 64-character hex links

✅ **Improved HTML Detection**
- Better pattern matching for HTML content
- Support for more HTML tags

✅ **External Image Support**
- HTTPS images load properly
- CSP meta tag injection

✅ **Better UI**
- Modern gradient design
- Improved error messages
- Loading indicators

## Installation

1. Download this folder
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" (top right)
4. Click "Load unpacked"
5. Select this folder
6. The extension icon will appear in your toolbar

## Usage

1. Click the extension icon
2. Paste a Kaspa transaction ID (64 hex characters)
3. Click "View Website"
4. If encrypted, enter the password
5. Click "Open Website" to render

## Features

- View HTML websites stored on Kaspa blockchain
- Decrypt encrypted websites with password
- Navigate between linked blockchain pages
- Support for external HTTPS images
- Clean, modern interface

## Version History

- v2.0.0: Added encryption, link navigation, improved detection
- v1.0.0: Initial release

## Support

For issues or questions, visit: https://kaspa.org

---
Built for the Kaspa decentralized web platform

# Features

Complete list of features in Kaspa Websites.

## Core Features

### Website Creation
- **HTML Editor** - Write HTML directly in the web interface
- **Live Preview** - See payload size in real-time
- **Character Counter** - Monitor content size
- **Recipient Address** - Specify transaction recipient
- **Amount Control** - Set KAS amount (default 1.0 KAS)

### Encryption
- **Toggle Encryption** - Checkbox to enable/disable
- **Password Protection** - Set password for encrypted sites
- **Password Visibility** - Show/hide password toggle
- **AES-256-GCM** - Military-grade encryption
- **PBKDF2 Key Derivation** - 100,000 iterations
- **Random Salt & IV** - Unique encryption for each site
- **ENC1 Marker** - Clear identification of encrypted content

### Image Support
- **Embedded Images** - Upload and convert to base64
- **Multiple Formats** - PNG, JPEG, GIF, WebP
- **Size Warnings** - Alert for large images (>100KB)
- **Image Preview** - Thumbnails before embedding
- **Auto HTML Generation** - Automatic <img> tag creation
- **External HTTPS Images** - Load images from secure URLs

### Website Viewing
- **Transaction ID Input** - 64-character hex validation
- **Auto-Detection** - Detects encrypted vs regular content
- **Payload Info Display** - Type, size, HTML detection status
- **HTML Rendering** - Open in new tab
- **Encryption Detection** - Automatic prompt for password
- **Decryption** - AES-256-GCM decryption with password

### Link Navigation
- **TX ID Links** - Use transaction IDs as hrefs
- **Link Interception** - Automatic detection of 64-hex links
- **New Tab Navigation** - Opens linked pages in new tabs
- **Normal Links** - HTTPS links work unchanged
- **Decentralized Web** - Chain of interconnected pages

## Technical Features

### Encoding/Decoding
- **Hex Encoding** - Convert HTML to hex
- **Double-Encoding Detection** - Handle double hex-encoded data
- **Recursive Decoding** - Automatic multi-layer decoding
- **0x Prefix Handling** - Smart prefix detection and removal

### Security
- **Content Security Policy** - Injection for external resources
- **HTTPS Only** - Block mixed content
- **Password Hashing** - PBKDF2 with 100K iterations
- **Secure Random** - Crypto-grade salt and IV generation

### Wallet Integration
- **KasWare Detection** - Auto-detect wallet
- **HTTPS Required** - Security enforcement
- **Transaction Confirmation** - User approval flow
- **Success Screen** - TX ID display with copy button
- **Error Handling** - User rejection, insufficient balance, etc.

### UI/UX
- **Modern Design** - Gradient backgrounds, smooth transitions
- **Responsive Layout** - Works on all screen sizes
- **Tab System** - Create vs View separation
- **Status Messages** - Success, error, info indicators
- **Loading States** - Clear feedback during operations
- **Button States** - Disabled during processing

## Advanced Features

### HTML Detection
Pattern matching for:
- HTML tags (html, head, body, div, p, span, etc.)
- Script and style tags
- Heading tags (h1-h6)
- DOCTYPE declarations
- Meta and link tags
- Image tags

### Error Handling
- Invalid TX ID format detection
- Transaction not found handling
- No payload found handling
- Decryption failure recovery
- Network error handling
- Wallet connection errors

### Browser Compatibility
- Chrome/Edge support
- Firefox support
- Modern browser features (Web Crypto API)
- Blob URL support
- Base64 encoding/decoding

## Chrome Extension Features

### Popup Interface
- Clean, modern UI
- Transaction ID input with validation
- View website button
- Payload information display
- Render button

### Encryption Support
- Password modal dialog
- Show/hide password toggle
- Decryption with feedback
- Error handling

### Link Navigation
- TX ID link detection
- Click interception
- New tab opening
- Extension page routing

### CSP Injection
- Automatic CSP meta tag
- External resource permissions
- Inline script/style support

## Planned Features

- [ ] Markdown editor
- [ ] CSS templates
- [ ] Multi-page site builder
- [ ] Website directory/search
- [ ] IPFS integration for large files
- [ ] Video embed support
- [ ] RSS feed generation
- [ ] Website analytics
- [ ] Comment system
- [ ] Version control

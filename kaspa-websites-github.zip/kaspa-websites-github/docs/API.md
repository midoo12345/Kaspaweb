# API Reference

JavaScript API documentation for Kaspa Websites.

## Core Functions

### Encoding Functions

#### `stringToHex(str)`
Converts a string to hexadecimal format.

**Parameters:**
- `str` (string): The string to convert

**Returns:**
- `string`: Hexadecimal representation

**Example:**
```javascript
const hex = stringToHex("<html>Hello World</html>");
// Returns: "3c68746d6c3e48656c6c6f20576f726c643c2f68746d6c3e"
```

---

#### `hexToString(hex)`
Converts hexadecimal to string with double-decode detection.

**Parameters:**
- `hex` (string): Hexadecimal string (with or without 0x prefix)

**Returns:**
- `string`: Decoded string

**Example:**
```javascript
const html = hexToString("3c68746d6c3e48656c6c6f20576f726c643c2f68746d6c3e");
// Returns: "<html>Hello World</html>"
```

---

### Encryption Functions

#### `encryptHTML(html, password)`
Encrypts HTML content using AES-256-GCM.

**Parameters:**
- `html` (string): HTML content to encrypt
- `password` (string): Password for encryption

**Returns:**
- `Promise<string>`: Encrypted data as hexadecimal

**Example:**
```javascript
const encrypted = await encryptHTML("<html>Secret</html>", "mypassword");
// Returns: hex string of encrypted data
```

**Encryption Details:**
- Algorithm: AES-256-GCM
- Key Derivation: PBKDF2
- Iterations: 100,000
- Hash: SHA-256
- Salt: 16 bytes (random)
- IV: 12 bytes (random)
- Output Format: salt(16) + iv(12) + encryptedData

---

#### `decryptHTML(encryptedHex, password)`
Decrypts AES-256-GCM encrypted HTML.

**Parameters:**
- `encryptedHex` (string): Encrypted data in hexadecimal
- `password` (string): Password for decryption

**Returns:**
- `Promise<string>`: Decrypted HTML

**Throws:**
- `Error`: If password is incorrect or data is corrupted

**Example:**
```javascript
try {
    const html = await decryptHTML(encryptedHex, "mypassword");
    console.log(html); // Original HTML
} catch (error) {
    console.error("Decryption failed:", error);
}
```

---

### Detection Functions

#### `detectHTML(text)`
Detects if text contains HTML markup.

**Parameters:**
- `text` (string): Text to analyze

**Returns:**
- `boolean`: true if HTML detected, false otherwise

**Example:**
```javascript
detectHTML("<html>Test</html>");  // Returns: true
detectHTML("Plain text");          // Returns: false
```

**Detection Patterns:**
- `<html>`, `<head>`, `<body>`
- `<div>`, `<p>`, `<span>`
- `<script>`, `<style>`
- `<h1>` through `<h6>`
- `<!DOCTYPE>`, `<title>`, `<meta>`, `<link>`, `<img>`

---

### Navigation Functions

#### `interceptKaspaLinks(html)`
Injects script to intercept Kaspa TX ID links.

**Parameters:**
- `html` (string): HTML content

**Returns:**
- `string`: HTML with interception script injected

**Example:**
```javascript
const processed = interceptKaspaLinks(originalHTML);
// Adds click handler for 64-hex-character links
```

**Link Pattern:**
- Detects: `/^[0-9a-fA-F]{64}$/`
- Action: Prevents default, opens new page with ?tx= parameter

---

### UI Functions

#### `showStatus(elementId, message, type)`
Displays status message to user.

**Parameters:**
- `elementId` (string): DOM element ID
- `message` (string): Message to display
- `type` (string): 'success', 'error', or 'info'

**Example:**
```javascript
showStatus('status', 'Website created!', 'success');
showStatus('status', 'Error occurred', 'error');
showStatus('status', 'Loading...', 'info');
```

---

#### `showPasswordPrompt()`
Shows modal dialog for password input.

**Returns:**
- `Promise<string|null>`: Password entered or null if cancelled

**Example:**
```javascript
const password = await showPasswordPrompt();
if (password) {
    // User entered password
} else {
    // User cancelled
}
```

**Features:**
- Password visibility toggle (eye icon)
- Enter key support
- Cancel button
- Modal overlay

---

## KasWare Integration

### `sendTransaction()`
Sends transaction to Kaspa blockchain via KasWare.

**Requires:**
- KasWare wallet extension
- HTTPS connection (or localhost)

**Process:**
```javascript
// 1. Get form data
const html = document.getElementById('htmlInput').value;
const recipient = document.getElementById('recipientAddress').value;
const amount = parseFloat(document.getElementById('amount').value);
const encrypt = document.getElementById('encryptCheckbox').checked;
const password = document.getElementById('encryptPassword').value;

// 2. Encrypt if needed
let hexPayload;
if (encrypt) {
    const encryptedHex = await encryptHTML(html, password);
    hexPayload = '454e4331' + encryptedHex; // Add ENC1 marker
} else {
    hexPayload = stringToHex(html);
}

// 3. Send transaction
const finalPayload = encrypt ? hexPayload : ('0x' + hexPayload);
const amountSompi = Math.floor(amount * 100000000);

const txId = await window.kasware.sendKaspa(
    recipient,
    amountSompi,
    { payload: finalPayload }
);

// 4. Extract transaction ID
const transactionId = typeof txId === 'string' ? txId : txId.id;
```

---

### `decodeTransaction()`
Fetches and decodes blockchain transaction.

**Process:**
```javascript
// 1. Validate TX ID
const txId = document.getElementById('txId').value.trim();
if (!/^[0-9a-fA-F]{64}$/.test(txId)) {
    showStatus('Invalid transaction ID format', 'error');
    return;
}

// 2. Fetch from Kaspa API
const response = await fetch(`https://api.kaspa.org/transactions/${txId}`);
const txData = await response.json();

// 3. Extract payload
let payload = txData.payload || txData.outputs[0].scriptPublicKey;

// 4. Decode hex
let decodedText = hexToString(payload);

// 5. Check for encryption
const isEncrypted = /^[0-9a-f]+$/i.test(decodedText) && 
                    decodedText.toLowerCase().startsWith('454e4331');

// 6. Decrypt if needed
if (isEncrypted) {
    const encryptedHex = decodedText.substring(8); // Remove ENC1
    const password = await showPasswordPrompt();
    decodedText = await decryptHTML(encryptedHex, password);
}

// 7. Display result
document.getElementById('htmlContent').textContent = decodedText;
```

---

## Image Embedding

### `fileToBase64(file)`
Converts file to base64 data URL.

**Parameters:**
- `file` (File): File object from input

**Returns:**
- `Promise<string>`: Base64 data URL

**Example:**
```javascript
const file = document.getElementById('imageUpload').files[0];
const base64 = await fileToBase64(file);
// Returns: "data:image/png;base64,iVBORw0KG..."
```

---

### `embedImages()`
Embeds selected images into HTML as base64.

**Process:**
```javascript
// 1. Get selected files
const files = document.getElementById('imageUpload').files;

// 2. Convert each to base64
for (let file of files) {
    // Check size
    if (file.size > 100000) {
        if (!confirm(`${file.name} is large. Continue?`)) continue;
    }
    
    // Convert
    const base64 = await fileToBase64(file);
    
    // Generate HTML
    const imgTag = `<img src="${base64}" alt="${file.name}" ` +
                  `style="max-width: 100%;">`;
    
    // Append to editor
    htmlContent += imgTag + '\n';
}
```

---

## Constants

### Encryption

```javascript
const ENCRYPTION_MARKER = '454e4331'; // "ENC1" in hex
const PBKDF2_ITERATIONS = 100000;
const SALT_LENGTH = 16; // bytes
const IV_LENGTH = 12;   // bytes
```

### Validation

```javascript
const TX_ID_PATTERN = /^[0-9a-fA-F]{64}$/;
const HEX_PATTERN = /^[0-9a-f]+$/i;
```

### API

```javascript
const KASPA_API_URL = 'https://api.kaspa.org';
const TRANSACTION_ENDPOINT = '/transactions/';
```

---

## Events

### Page Load

```javascript
window.addEventListener('load', () => {
    // Check for ?tx= parameter
    const urlParams = new URLSearchParams(window.location.search);
    const txId = urlParams.get('tx');
    
    if (txId) {
        switchTab('decoder');
        document.getElementById('txId').value = txId;
        setTimeout(() => decodeTransaction(), 500);
    }
});
```

### Click Events

```javascript
// In rendered HTML
document.addEventListener('click', function(e) {
    const link = e.target.closest('a');
    if (!link) return;
    
    const href = link.getAttribute('href');
    if (!href || !TX_ID_PATTERN.test(href)) return;
    
    e.preventDefault();
    window.open('kaspawebsites.html?tx=' + href + '#decoder', '_blank');
}, false);
```

---

## Error Handling

### Common Errors

```javascript
// Transaction not found
if (!response.ok) {
    throw new Error('Transaction not found');
}

// No payload
if (!payload) {
    showStatus('No payload found', 'error');
    return;
}

// Decryption failed
try {
    decodedText = await decryptHTML(hex, password);
} catch (error) {
    showStatus('Wrong password', 'error');
    return;
}

// KasWare not detected
if (typeof window.kasware === 'undefined') {
    alert('KasWare wallet not detected');
    return;
}

// Not HTTPS
if (window.location.protocol !== 'https:' && 
    window.location.hostname !== 'localhost') {
    alert('KasWare requires HTTPS');
    return;
}
```

---

## Best Practices

### Security

1. **Never log passwords**
   ```javascript
   // ❌ Bad
   console.log('Password:', password);
   
   // ✅ Good
   console.log('Password length:', password.length);
   ```

2. **Clear sensitive data**
   ```javascript
   password = '';
   encryptedHex = '';
   ```

3. **Validate input**
   ```javascript
   if (!TX_ID_PATTERN.test(txId)) {
       showStatus('Invalid TX ID', 'error');
       return;
   }
   ```

### Performance

1. **Check file sizes**
   ```javascript
   if (file.size > 100000) {
       if (!confirm('File is large. Continue?')) return;
   }
   ```

2. **Use async/await**
   ```javascript
   const encrypted = await encryptHTML(html, password);
   ```

3. **Cache results**
   ```javascript
   let decodedHTML = ''; // Cache decoded result
   ```

### User Experience

1. **Show loading states**
   ```javascript
   showStatus('Loading...', 'info');
   ```

2. **Provide feedback**
   ```javascript
   showStatus('✅ Success!', 'success');
   ```

3. **Handle errors gracefully**
   ```javascript
   catch (error) {
       showStatus('Error: ' + error.message, 'error');
   }
   ```

---

## Extension API (Chrome)

### Manifest

```json
{
  "manifest_version": 3,
  "permissions": ["activeTab", "storage"],
  "host_permissions": ["https://api.kaspa.org/*"]
}
```

### Opening New Tabs

```javascript
chrome.tabs.create({ url: blobURL });
```

### Storage

```javascript
// Save
chrome.storage.local.set({ txId: transactionId });

// Retrieve
chrome.storage.local.get(['txId'], (result) => {
    console.log(result.txId);
});
```

---

For more examples and usage, see the [Implementation Guide](IMPLEMENTATION_GUIDE.md).

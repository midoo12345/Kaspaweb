# Contributing to Kaspa Websites

Thank you for your interest in contributing to Kaspa Websites! This document provides guidelines for contributing to the project.

## Code of Conduct

- Be respectful and inclusive
- Provide constructive feedback
- Focus on what is best for the community
- Show empathy towards other community members

## How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported in [Issues](https://github.com/yourusername/kaspa-websites/issues)
2. If not, create a new issue with:
   - Clear title and description
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots if applicable
   - Browser/OS information

### Suggesting Features

1. Check existing feature requests
2. Create a new issue with:
   - Clear description of the feature
   - Use cases and benefits
   - Possible implementation approach

### Pull Requests

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes**
   - Follow the coding style
   - Add comments for complex logic
   - Update documentation if needed
4. **Test thoroughly**
   - Test in multiple browsers
   - Test encryption/decryption
   - Test link navigation
5. **Commit your changes**
   ```bash
   git commit -m "Add feature: description"
   ```
6. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```
7. **Create a Pull Request**

## Development Guidelines

### Code Style

- Use consistent indentation (4 spaces)
- Use meaningful variable names
- Add comments for complex logic
- Keep functions focused and small
- Handle errors gracefully

### JavaScript Style

```javascript
// Good
async function encryptHTML(html, password) {
    if (!html || !password) {
        throw new Error('Missing required parameters');
    }
    // ...
}

// Avoid
async function e(h, p) { ... }
```

### HTML/CSS Style

```html
<!-- Good -->
<div class="container">
    <h1>Title</h1>
    <p>Content</p>
</div>

<!-- Avoid -->
<div class="container"><h1>Title</h1><p>Content</p></div>
```

### Testing

Before submitting:

1. **Test basic functionality**
   - Create unencrypted website
   - Create encrypted website
   - View both types
   - Test link navigation

2. **Test edge cases**
   - Invalid TX IDs
   - Wrong passwords
   - Large payloads
   - Network errors

3. **Test browsers**
   - Chrome/Edge
   - Firefox
   - Safari (if applicable)

### Documentation

- Update README.md if adding features
- Update API.md for new functions
- Add comments to complex code
- Include examples where helpful

## Areas Needing Contribution

### High Priority
- [ ] Bug fixes
- [ ] Security improvements
- [ ] Performance optimizations
- [ ] Browser compatibility

### Medium Priority
- [ ] UI/UX improvements
- [ ] Additional features
- [ ] Better error messages
- [ ] Accessibility improvements

### Low Priority
- [ ] Code refactoring
- [ ] Additional examples
- [ ] Documentation improvements
- [ ] Visual enhancements

## Specific Contribution Ideas

### Easy (Good First Issues)
- Add more sample websites
- Improve error messages
- Add loading animations
- Fix typos in documentation

### Medium
- Add markdown support
- Create website templates
- Implement search functionality
- Add keyboard shortcuts

### Advanced
- IPFS integration
- Multi-page site builder
- Website analytics
- Comment system

## Questions?

- Open an issue for questions
- Join [Kaspa Discord](https://discord.gg/kaspa)
- Check existing documentation

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to the decentralized web! 🚀

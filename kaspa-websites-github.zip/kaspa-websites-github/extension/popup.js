let decodedHTML = '';

document.addEventListener('DOMContentLoaded', function() {
    const decodeBtn = document.getElementById('decodeBtn');
    const renderBtn = document.getElementById('renderBtn');
    const txIdInput = document.getElementById('txId');
    
    decodeBtn.addEventListener('click', decodeTransaction);
    renderBtn.addEventListener('click', renderHTML);
    
    // Enter key support
    txIdInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') decodeTransaction();
    });
});

async function decodeTransaction() {
    const txId = document.getElementById('txId').value.trim();
    
    if (!txId) {
        showStatus('Please enter a transaction ID', 'error');
        return;
    }
    
    if (!/^[0-9a-fA-F]{64}$/.test(txId)) {
        showStatus('Invalid transaction ID format', 'error');
        return;
    }
    
    showStatus('Fetching transaction...', 'info');
    
    try {
        const response = await fetch(`https://api.kaspa.org/transactions/${txId}`);
        
        if (!response.ok) {
            throw new Error('Transaction not found');
        }
        
        const txData = await response.json();
        console.log('Transaction data:', txData);
        
        let payload = null;
        
        // Try different payload locations
        if (txData.payload) {
            payload = txData.payload;
        } else if (txData.outputs && txData.outputs.length > 0) {
            for (const output of txData.outputs) {
                if (output.scriptPublicKey) {
                    payload = output.scriptPublicKey;
                    break;
                }
            }
        }
        
        if (!payload) {
            showStatus('No payload found in this transaction', 'error');
            return;
        }
        
        console.log('========== DECODING TRANSACTION ==========');
        console.log('Raw payload hex (first 100 chars):', payload.substring(0, 100));
        
        // Fully decode the payload (handles double-encoding)
        let decodedText = hexToString(payload);
        console.log('Fully decoded text length:', decodedText.length);
        console.log('Fully decoded text (first 100 chars):', decodedText.substring(0, 100));
        
        // Check if it's hex and starts with ENC1 marker
        const looksLikeHex = /^[0-9a-f]+$/i.test(decodedText);
        console.log('Decoded text looks like hex?', looksLikeHex);
        
        if (looksLikeHex && decodedText.toLowerCase().startsWith('454e4331')) {
            console.log('Found ENC1 marker in hex format - this is encrypted!');
            
            const encryptedHex = decodedText.substring(8); // Remove ENC1
            console.log('Encrypted hex length:', encryptedHex.length);
            
            const password = await showPasswordPrompt();
            
            if (!password) {
                showStatus('Decryption cancelled', 'error');
                return;
            }
            
            console.log('Attempting decryption...');
            
            try {
                showStatus('Decrypting website...', 'info');
                decodedText = await decryptHTML(encryptedHex, password);
                console.log('✅ Decrypted successfully!');
                console.log('Decrypted text (first 200 chars):', decodedText.substring(0, 200));
            } catch (error) {
                console.error('❌ Decryption failed:', error);
                showStatus('❌ Decryption failed. Wrong password?', 'error');
                return;
            }
        } else if (decodedText.startsWith('ENC1')) {
            console.log('Found ENC1 marker in decoded text - old format');
            showStatus('❌ Old encrypted format not supported. Please create a new encrypted website.', 'error');
            return;
        } else {
            console.log('Not encrypted - regular content');
        }
        
        const isHTML = detectHTML(decodedText);
        console.log('HTML detected:', isHTML);
        console.log('==========================================');
        
        const wasEncrypted = looksLikeHex && decodedText !== hexToString(payload);
        
        document.getElementById('payloadType').textContent = isHTML ? (wasEncrypted ? '🔒 Encrypted HTML' : 'HTML Document') : 'Text Data';
        document.getElementById('payloadSize').textContent = `${decodedText.length} chars`;
        document.getElementById('htmlDetected').textContent = isHTML ? '✅ Yes' : '❌ No';
        document.getElementById('payloadInfo').className = 'show';
        
        decodedHTML = decodedText;
        
        if (isHTML) {
            showStatus(wasEncrypted ? '🔒 Encrypted website decrypted!' : 'Website decoded successfully!', 'success');
        } else {
            showStatus('Content decoded. You can still try to render it.', 'info');
        }
        
    } catch (error) {
        console.error('Decode error:', error);
        showStatus('Error: ' + error.message, 'error');
    }
}

function hexToString(hex) {
    // Remove any 0x prefix
    hex = hex.replace(/^0x/, '');
    
    let str = '';
    for (let i = 0; i < hex.length; i += 2) {
        const charCode = parseInt(hex.substr(i, 2), 16);
        str += String.fromCharCode(charCode);
    }
    
    // Check if double-encoded (starts with 0x after first decode)
    if (str.startsWith('0x') || str.startsWith('30783')) {
        console.log('Detected double-encoded payload, decoding again...');
        return hexToString(str);
    }
    
    return str;
}

function detectHTML(text) {
    const patterns = [
        /<html/i,
        /<head/i,
        /<body/i,
        /<div/i,
        /<p>/i,
        /<span/i,
        /<script/i,
        /<style/i,
        /<h[1-6]/i,
        /<!DOCTYPE/i,
        /<title/i,
        /<meta/i,
        /<link/i,
        /<img/i
    ];
    
    const hasHTMLTags = patterns.some(pattern => pattern.test(text));
    const trimmed = text.trim();
    const startsWithHTML = /^<!DOCTYPE|^<html|^<head|^<body/i.test(trimmed);
    
    return hasHTMLTags || startsWithHTML;
}

async function decryptHTML(encryptedHex, password) {
    const bytes = new Uint8Array(encryptedHex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
    
    const salt = bytes.slice(0, 16);
    const iv = bytes.slice(16, 28);
    const encryptedData = bytes.slice(28);
    
    const encoder = new TextEncoder();
    const passwordKey = await crypto.subtle.importKey(
        'raw',
        encoder.encode(password),
        'PBKDF2',
        false,
        ['deriveBits', 'deriveKey']
    );
    
    const key = await crypto.subtle.deriveKey(
        {
            name: 'PBKDF2',
            salt: salt,
            iterations: 100000,
            hash: 'SHA-256'
        },
        passwordKey,
        { name: 'AES-GCM', length: 256 },
        false,
        ['decrypt']
    );
    
    const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        encryptedData
    );
    
    const decoder = new TextDecoder();
    return decoder.decode(decrypted);
}

function showPasswordPrompt() {
    return new Promise((resolve) => {
        const modal = document.getElementById('passwordModal');
        const passwordInput = document.getElementById('decryptPassword');
        const toggleBtn = document.getElementById('togglePassword');
        const cancelBtn = document.getElementById('cancelPassword');
        const confirmBtn = document.getElementById('confirmPassword');
        
        modal.className = 'modal show';
        passwordInput.value = '';
        passwordInput.type = 'password';
        toggleBtn.textContent = '👁️';
        
        // Show/hide password toggle
        toggleBtn.onclick = () => {
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleBtn.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleBtn.textContent = '👁️';
            }
        };
        
        // Cancel
        cancelBtn.onclick = () => {
            modal.className = 'modal';
            resolve(null);
        };
        
        // Confirm
        const confirm = () => {
            const password = passwordInput.value;
            modal.className = 'modal';
            resolve(password);
        };
        
        confirmBtn.onclick = confirm;
        passwordInput.onkeypress = (e) => {
            if (e.key === 'Enter') confirm();
        };
        
        // Focus input
        setTimeout(() => passwordInput.focus(), 100);
    });
}

function renderHTML() {
    if (!decodedHTML) return;
    
    // Process HTML to intercept Kaspa TX ID links
    let processedHTML = interceptKaspaLinks(decodedHTML);
    
    // Add CSP meta tag to allow external resources
    if (!processedHTML.toLowerCase().includes('content-security-policy')) {
        const cspMeta = '<meta http-equiv="Content-Security-Policy" content="default-src * \'unsafe-inline\' \'unsafe-eval\' data: blob:;">';
        
        if (processedHTML.toLowerCase().includes('<head>')) {
            processedHTML = processedHTML.replace(/<head>/i, '<head>' + cspMeta);
        } else if (processedHTML.toLowerCase().includes('<html>')) {
            processedHTML = processedHTML.replace(/<html>/i, '<html><head>' + cspMeta + '</head>');
        } else {
            processedHTML = '<html><head>' + cspMeta + '</head><body>' + processedHTML + '</body></html>';
        }
    }
    
    const blob = new Blob([processedHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    chrome.tabs.create({ url: url });
    
    showStatus('Website opened in new tab!', 'success');
}

function interceptKaspaLinks(html) {
    const script = `
        <script>
        (function() {
            document.addEventListener('click', function(e) {
                const link = e.target.closest('a');
                if (!link) return;
                
                const href = link.getAttribute('href');
                if (!href) return;
                
                // Check if it's a Kaspa TX ID (64 hex characters)
                if (/^[0-9a-fA-F]{64}$/.test(href)) {
                    e.preventDefault();
                    
                    // Open extension popup with this TX ID
                    // Since we can't directly open popup, we'll open the extension page
                    const extensionUrl = 'chrome-extension://' + chrome.runtime.id + '/popup.html?tx=' + href;
                    window.open(extensionUrl, '_blank');
                }
            }, false);
        })();
        </script>
    `;
    
    // Inject the script before </body> or at the end
    if (html.toLowerCase().includes('</body>')) {
        return html.replace(/<\/body>/i, script + '</body>');
    } else {
        return html + script;
    }
}

function showStatus(message, type) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = `show ${type}`;
    
    if (type === 'success' || type === 'error') {
        setTimeout(() => {
            if (type === 'error') {
                status.className = '';
            }
        }, 10000);
    }
}
